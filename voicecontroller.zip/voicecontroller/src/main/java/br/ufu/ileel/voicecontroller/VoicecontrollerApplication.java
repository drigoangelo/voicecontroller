package br.ufu.ileel.voicecontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoicecontrollerApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoicecontrollerApplication.class, args);
	}

}
